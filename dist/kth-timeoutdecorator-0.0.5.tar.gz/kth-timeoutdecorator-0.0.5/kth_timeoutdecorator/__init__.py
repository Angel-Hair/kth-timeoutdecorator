from .kth_timeoutdecorator import timeout
from .kth_timeoutdecorator import TimeoutException

__title__ = 'kth_timeoutdecorator'
__version__ = '0.0.5'