from .th_timeoutdecorator import timeout
from .th_timeoutdecorator import TimeoutException

__title__ = 'th_timeoutdecorator'
__version__ = '0.0.2'